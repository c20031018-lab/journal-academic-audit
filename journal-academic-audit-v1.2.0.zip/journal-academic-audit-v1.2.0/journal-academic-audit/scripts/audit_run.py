#!/usr/bin/env python3
"""Validate a journal-academic-audit output package using only stdlib."""

from __future__ import annotations

import argparse
import csv
import json
import sys
import tempfile
from datetime import date, datetime
from pathlib import Path


LEDGER_FIELDS = [
    "claim_id", "journal", "issn", "section", "field", "claim", "critical",
    "source_url", "source_title", "source_level", "source_date", "access_date",
    "valid_for_year", "scope", "evidence_status", "confidence", "analysis_level", "notes",
]
CORPUS_FIELDS = [
    "record_id", "journal", "issn", "year", "issue", "title", "authors", "pages",
    "doi", "stable_id", "document_type", "abstract_available", "fulltext_available",
    "source_url", "verification_status",
]
PAPER_FIELDS = [
    "paper_id", "journal", "title", "authors", "year", "venue", "volume", "issue",
    "pages", "doi", "stable_id", "document_type", "verification_status", "analysis_level",
    "selection_reason", "source_url", "fulltext_source_url",
]
ISSUE_FIELDS = [
    "issue_id", "reviewer", "round", "location", "dimension", "severity",
    "description", "action", "status", "notes",
]
SEARCH_FIELDS = {
    "search_date", "cutoff_date", "scope", "queries", "sources_attempted",
    "sources_succeeded", "sources_failed", "sources_not_connected", "dedup_before",
    "dedup_after", "dedup_rules",
}
CAPSULE_FIELDS = {
    "capsule_version", "updated_at", "mode", "checkpoint", "task_scope",
    "journal_identity", "confirmed_claim_ids", "representative_paper_ids",
    "open_questions", "source_conflicts", "completed_steps", "next_actions",
    "hard_constraints", "artifact_index", "review_state",
}
CHECKPOINTS = {
    "identity", "search", "papers", "predraft", "review_round_1",
    "review_round_2", "final",
}
QUESTION_STATUSES = {"open", "manual_review", "resolved"}

EVIDENCE_STATUSES = {
    "verified", "partially_verified", "not_public", "not_found", "source_conflict",
    "manual_review", "not_applicable",
}
CONFIDENCES = {"high", "medium", "low", "not_assessed"}
ANALYSIS_LEVELS = {"fulltext", "abstract", "bibliographic", "not_applicable"}
VERIFICATION_STATUSES = {
    "verified", "partially_verified", "manual_review", "mismatch", "not_found",
}
SEVERITIES = {"blocker", "major", "general", "minor"}
ISSUE_STATUSES = {"fixed", "downgraded", "deleted", "manual_review", "accepted_risk"}
BOOLEANS = {"true", "false"}


class Audit:
    def __init__(self) -> None:
        self.errors: list[str] = []
        self.warnings: list[str] = []

    def error(self, message: str) -> None:
        self.errors.append(message)

    def warn(self, message: str) -> None:
        self.warnings.append(message)


def read_csv(path: Path, required: list[str], audit: Audit) -> list[dict[str, str]]:
    try:
        with path.open("r", encoding="utf-8-sig", newline="") as handle:
            reader = csv.DictReader(handle)
            headers = reader.fieldnames or []
            missing = [field for field in required if field not in headers]
            if missing:
                audit.error(f"{path.name}: missing fields: {', '.join(missing)}")
            return [{key: (value or "").strip() for key, value in row.items()} for row in reader]
    except (OSError, csv.Error) as exc:
        audit.error(f"{path.name}: cannot read CSV: {exc}")
        return []


def unique(rows: list[dict[str, str]], field: str, filename: str, audit: Audit) -> None:
    seen: set[str] = set()
    for number, row in enumerate(rows, start=2):
        value = row.get(field, "")
        if not value:
            audit.error(f"{filename}:{number}: {field} is required")
        elif value in seen:
            audit.error(f"{filename}:{number}: duplicate {field}={value}")
        seen.add(value)


def enum(value: str, allowed: set[str], label: str, audit: Audit) -> None:
    if value not in allowed:
        audit.error(f"{label}: invalid value {value!r}; allowed={sorted(allowed)}")


def iso_date(value: str, label: str, audit: Audit, required: bool = False) -> None:
    if not value:
        if required:
            audit.error(f"{label}: date is required")
        return
    try:
        parsed = date.fromisoformat(value)
        if parsed > date.today():
            audit.warn(f"{label}: date {value} is in the future")
    except ValueError:
        audit.error(f"{label}: expected ISO date YYYY-MM-DD, got {value!r}")


def validate_ledger(path: Path, audit: Audit) -> list[dict[str, str]]:
    rows = read_csv(path, LEDGER_FIELDS, audit)
    unique(rows, "claim_id", path.name, audit)
    for number, row in enumerate(rows, start=2):
        prefix = f"{path.name}:{number}"
        for field in ("journal", "section", "field", "claim"):
            if not row.get(field):
                audit.error(f"{prefix}: {field} is required")
        enum(row.get("critical", ""), BOOLEANS, f"{prefix}:critical", audit)
        enum(row.get("evidence_status", ""), EVIDENCE_STATUSES, f"{prefix}:evidence_status", audit)
        enum(row.get("confidence", ""), CONFIDENCES, f"{prefix}:confidence", audit)
        enum(row.get("analysis_level", ""), ANALYSIS_LEVELS, f"{prefix}:analysis_level", audit)
        iso_date(row.get("source_date", ""), f"{prefix}:source_date", audit)
        iso_date(row.get("access_date", ""), f"{prefix}:access_date", audit)
        level = row.get("source_level", "")
        if level and level not in {"1", "2", "3", "4"}:
            audit.error(f"{prefix}: source_level must be 1, 2, 3, 4 or blank")
        if row.get("evidence_status") == "verified":
            for field in ("source_url", "source_title", "source_level", "access_date"):
                if not row.get(field):
                    audit.error(f"{prefix}: verified claim requires {field}")
        if row.get("critical") == "true" and level == "4":
            audit.error(f"{prefix}: critical claim cannot rely on source_level=4")
        if row.get("confidence") == "high" and row.get("evidence_status") in {"not_found", "manual_review"}:
            audit.warn(f"{prefix}: high confidence with {row.get('evidence_status')} needs explanation")
    return rows


def validate_corpus(path: Path, audit: Audit) -> list[dict[str, str]]:
    rows = read_csv(path, CORPUS_FIELDS, audit)
    unique(rows, "record_id", path.name, audit)
    composites: set[tuple[str, str, str, str]] = set()
    for number, row in enumerate(rows, start=2):
        prefix = f"{path.name}:{number}"
        for field in ("journal", "year", "title"):
            if not row.get(field):
                audit.error(f"{prefix}: {field} is required")
        for field in ("abstract_available", "fulltext_available"):
            enum(row.get(field, ""), BOOLEANS, f"{prefix}:{field}", audit)
        enum(row.get("verification_status", ""), VERIFICATION_STATUSES, f"{prefix}:verification_status", audit)
        key = (row.get("journal", "").casefold(), row.get("year", ""), row.get("title", "").casefold(), row.get("authors", "").casefold())
        if key in composites:
            audit.warn(f"{prefix}: possible duplicate normalized bibliography")
        composites.add(key)
    return rows


def validate_papers(path: Path, audit: Audit) -> list[dict[str, str]]:
    rows = read_csv(path, PAPER_FIELDS, audit)
    unique(rows, "paper_id", path.name, audit)
    for number, row in enumerate(rows, start=2):
        prefix = f"{path.name}:{number}"
        for field in ("journal", "title", "year", "selection_reason"):
            if not row.get(field):
                audit.error(f"{prefix}: {field} is required")
        enum(row.get("verification_status", ""), VERIFICATION_STATUSES, f"{prefix}:verification_status", audit)
        enum(row.get("analysis_level", ""), ANALYSIS_LEVELS, f"{prefix}:analysis_level", audit)
        if row.get("verification_status") == "verified" and not row.get("source_url"):
            audit.error(f"{prefix}: verified paper requires source_url")
        if row.get("analysis_level") == "fulltext" and not row.get("fulltext_source_url"):
            audit.error(f"{prefix}: fulltext analysis requires fulltext_source_url")
    return rows


def validate_issues(path: Path, audit: Audit) -> list[dict[str, str]]:
    rows = read_csv(path, ISSUE_FIELDS, audit)
    unique(rows, "issue_id", path.name, audit)
    for number, row in enumerate(rows, start=2):
        prefix = f"{path.name}:{number}"
        if not row.get("reviewer"):
            audit.error(f"{prefix}: reviewer is required")
        if row.get("round") not in {"1", "2"}:
            audit.error(f"{prefix}: round must be 1 or 2")
        enum(row.get("severity", ""), SEVERITIES, f"{prefix}:severity", audit)
        enum(row.get("status", ""), ISSUE_STATUSES, f"{prefix}:status", audit)
        if row.get("severity") == "blocker" and row.get("status") in {"manual_review", "accepted_risk"}:
            audit.error(f"{prefix}: blocker must be fixed, downgraded or deleted")
        if row.get("severity") == "major" and row.get("status") == "accepted_risk":
            audit.error(f"{prefix}: major issue cannot be accepted_risk")
    return rows


def validate_search(path: Path, audit: Audit) -> dict:
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        audit.error(f"{path.name}: cannot read JSON: {exc}")
        return {}
    if not isinstance(data, dict):
        audit.error(f"{path.name}: top level must be an object")
        return {}
    missing = sorted(SEARCH_FIELDS - data.keys())
    if missing:
        audit.error(f"{path.name}: missing fields: {', '.join(missing)}")
    iso_date(str(data.get("search_date", "")), f"{path.name}:search_date", audit, required=True)
    iso_date(str(data.get("cutoff_date", "")), f"{path.name}:cutoff_date", audit, required=True)
    for field in ("queries", "sources_attempted", "sources_succeeded", "sources_failed", "sources_not_connected", "dedup_rules"):
        if not isinstance(data.get(field), list):
            audit.error(f"{path.name}:{field} must be a list")
    attempted = set(data.get("sources_attempted", [])) if isinstance(data.get("sources_attempted"), list) else set()
    succeeded = set(data.get("sources_succeeded", [])) if isinstance(data.get("sources_succeeded"), list) else set()
    for source in succeeded - attempted:
        audit.error(f"{path.name}: succeeded source {source!r} was not attempted")
    failures = data.get("sources_failed", [])
    if isinstance(failures, list):
        for index, failure in enumerate(failures):
            if not isinstance(failure, dict) or not failure.get("source") or not failure.get("reason"):
                audit.error(f"{path.name}:sources_failed[{index}] requires source and reason")
            elif failure["source"] not in attempted:
                audit.error(f"{path.name}: failed source {failure['source']!r} was not attempted")
    before, after = data.get("dedup_before"), data.get("dedup_after")
    if not isinstance(before, int) or before < 0 or not isinstance(after, int) or after < 0:
        audit.error(f"{path.name}: dedup counts must be non-negative integers")
    elif after > before:
        audit.error(f"{path.name}: dedup_after cannot exceed dedup_before")
    return data


def validate_capsule(
    path: Path,
    directory: Path,
    mode: str,
    ledger: list[dict[str, str]],
    papers: list[dict[str, str]],
    audit: Audit,
) -> dict:
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        audit.error(f"{path.name}: cannot read JSON: {exc}")
        return {}
    if not isinstance(data, dict):
        audit.error(f"{path.name}: top level must be an object")
        return {}
    missing = sorted(CAPSULE_FIELDS - data.keys())
    if missing:
        audit.error(f"{path.name}: missing fields: {', '.join(missing)}")

    version = data.get("capsule_version")
    if not isinstance(version, int) or isinstance(version, bool) or version < 1:
        audit.error(f"{path.name}: capsule_version must be a positive integer")
    timestamp = data.get("updated_at")
    if not isinstance(timestamp, str):
        audit.error(f"{path.name}: updated_at must be an ISO datetime string")
    else:
        try:
            parsed = datetime.fromisoformat(timestamp)
            if parsed.tzinfo is None:
                audit.error(f"{path.name}: updated_at must include a timezone")
        except ValueError:
            audit.error(f"{path.name}: invalid updated_at {timestamp!r}")
    if data.get("mode") != mode:
        audit.error(f"{path.name}: mode {data.get('mode')!r} does not match --mode {mode!r}")
    if data.get("checkpoint") not in CHECKPOINTS:
        audit.error(f"{path.name}: invalid checkpoint {data.get('checkpoint')!r}")

    for field in ("task_scope", "journal_identity", "artifact_index", "review_state"):
        if not isinstance(data.get(field), dict):
            audit.error(f"{path.name}:{field} must be an object")
    for field in (
        "confirmed_claim_ids", "representative_paper_ids", "open_questions",
        "source_conflicts", "completed_steps", "next_actions", "hard_constraints",
    ):
        if not isinstance(data.get(field), list):
            audit.error(f"{path.name}:{field} must be a list")

    claim_ids = {row.get("claim_id", "") for row in ledger}
    paper_ids = {row.get("paper_id", "") for row in papers}

    def check_claim_refs(values: object, label: str) -> None:
        if not isinstance(values, list):
            return
        for value in values:
            if not isinstance(value, str) or value not in claim_ids:
                audit.error(f"{path.name}:{label}: unknown claim_id {value!r}")

    confirmed = data.get("confirmed_claim_ids")
    check_claim_refs(confirmed, "confirmed_claim_ids")
    if isinstance(confirmed, list) and not confirmed:
        audit.error(f"{path.name}: confirmed_claim_ids must not be empty")
    paper_refs = data.get("representative_paper_ids")
    if isinstance(paper_refs, list):
        for value in paper_refs:
            if not isinstance(value, str) or value not in paper_ids:
                audit.error(f"{path.name}:representative_paper_ids: unknown paper_id {value!r}")
    identity = data.get("journal_identity")
    if isinstance(identity, dict):
        check_claim_refs(identity.get("claim_ids"), "journal_identity.claim_ids")

    questions = data.get("open_questions")
    if isinstance(questions, list):
        for index, question in enumerate(questions):
            label = f"open_questions[{index}]"
            if not isinstance(question, dict) or not question.get("question"):
                audit.error(f"{path.name}:{label} requires question")
                continue
            if question.get("status") not in QUESTION_STATUSES:
                audit.error(f"{path.name}:{label}: invalid status {question.get('status')!r}")
            check_claim_refs(question.get("related_claim_ids", []), f"{label}.related_claim_ids")

    conflicts = data.get("source_conflicts")
    if isinstance(conflicts, list):
        for index, conflict in enumerate(conflicts):
            label = f"source_conflicts[{index}]"
            if not isinstance(conflict, dict) or not conflict.get("summary") or not conflict.get("status"):
                audit.error(f"{path.name}:{label} requires summary and status")
                continue
            check_claim_refs(conflict.get("claim_ids", []), f"{label}.claim_ids")

    for field in ("completed_steps", "next_actions", "hard_constraints"):
        values = data.get(field)
        if isinstance(values, list) and any(not isinstance(value, str) or not value.strip() for value in values):
            audit.error(f"{path.name}:{field} must contain non-empty strings")

    artifact_index = data.get("artifact_index")
    required_artifacts = {
        "evidence_ledger", "search_log", "representative_papers",
        "review_issues", "context_capsule", "final_report",
    }
    if mode in {"full", "compare"}:
        required_artifacts.add("corpus")
    if isinstance(artifact_index, dict):
        missing_artifacts = sorted(required_artifacts - artifact_index.keys())
        if missing_artifacts:
            audit.error(f"{path.name}:artifact_index missing: {', '.join(missing_artifacts)}")
        root = directory.resolve()
        for key, value in artifact_index.items():
            if not isinstance(value, str) or not value:
                audit.error(f"{path.name}:artifact_index.{key} must be a non-empty relative path")
                continue
            candidate = (directory / value).resolve()
            try:
                candidate.relative_to(root)
            except ValueError:
                audit.error(f"{path.name}:artifact_index.{key} escapes audit directory")
                continue
            if not candidate.is_file():
                audit.error(f"{path.name}:artifact_index.{key} does not exist: {value}")

    review = data.get("review_state")
    if isinstance(review, dict):
        for field in ("current_round", "blockers_open", "major_open"):
            value = review.get(field)
            if not isinstance(value, int) or isinstance(value, bool) or value < 0:
                audit.error(f"{path.name}:review_state.{field} must be a non-negative integer")
        if not isinstance(review.get("independent_review"), bool):
            audit.error(f"{path.name}:review_state.independent_review must be boolean")
        if data.get("checkpoint") == "final":
            if review.get("blockers_open") != 0 or review.get("major_open") != 0:
                audit.error(f"{path.name}: final checkpoint cannot have open blocker or major issues")
    return data


def validate_run(directory: Path, mode: str) -> Audit:
    audit = Audit()
    required = {
        "evidence-ledger.csv", "search-log.json", "representative-papers.csv",
        "review-issues.csv", "context-capsule.json", "final-report.md",
    }
    if mode in {"full", "compare"}:
        required.add("corpus.csv")
    for filename in sorted(required):
        if not (directory / filename).is_file():
            audit.error(f"missing required file: {filename}")
    ledger = validate_ledger(directory / "evidence-ledger.csv", audit) if (directory / "evidence-ledger.csv").is_file() else []
    corpus = validate_corpus(directory / "corpus.csv", audit) if (directory / "corpus.csv").is_file() else []
    papers = validate_papers(directory / "representative-papers.csv", audit) if (directory / "representative-papers.csv").is_file() else []
    if (directory / "review-issues.csv").is_file():
        validate_issues(directory / "review-issues.csv", audit)
    log = validate_search(directory / "search-log.json", audit) if (directory / "search-log.json").is_file() else {}
    if (directory / "context-capsule.json").is_file():
        validate_capsule(directory / "context-capsule.json", directory, mode, ledger, papers, audit)
    report_path = directory / "final-report.md"
    report = report_path.read_text(encoding="utf-8") if report_path.is_file() else ""
    if report_path.is_file() and not report.strip():
        audit.error("final-report.md: report is empty")
    if mode == "quick" and not (directory / "corpus.csv").is_file():
        trend_terms = ("年度趋势", "关键词共现", "词频", "year-over-year", "co-occurrence")
        if any(term in report for term in trend_terms):
            audit.error("quick mode: trend/co-occurrence claims require corpus.csv")
    if mode in {"full", "compare"} and log and corpus:
        after = log.get("dedup_after")
        if isinstance(after, int) and after != len(corpus):
            audit.warn(f"search-log dedup_after={after} but corpus rows={len(corpus)}")
    if mode == "compare":
        journals = {row.get("journal", "") for row in ledger + corpus + papers if row.get("journal")}
        if len(journals) < 2:
            audit.error("compare mode requires at least two distinct journal values")
    return audit


def write_csv(path: Path, fields: list[str], rows: list[dict[str, str]]) -> None:
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def self_test() -> None:
    with tempfile.TemporaryDirectory(prefix="journal-audit-") as temp:
        root = Path(temp)
        ledger_row = {field: "" for field in LEDGER_FIELDS}
        ledger_row.update({
            "claim_id": "c1", "journal": "Test Journal", "issn": "0000-0000",
            "section": "identity", "field": "title", "claim": "Test Journal",
            "critical": "true", "source_url": "https://example.org/journal",
            "source_title": "Official journal", "source_level": "1",
            "source_date": "2025-01-01", "access_date": "2025-01-02",
            "valid_for_year": "2025", "scope": "current", "evidence_status": "verified",
            "confidence": "high", "analysis_level": "not_applicable",
        })
        write_csv(root / "evidence-ledger.csv", LEDGER_FIELDS, [ledger_row])
        corpus_row = {field: "" for field in CORPUS_FIELDS}
        corpus_row.update({
            "record_id": "r1", "journal": "Test Journal", "issn": "0000-0000",
            "year": "2025", "title": "A paper", "authors": "A. Author",
            "abstract_available": "true", "fulltext_available": "false",
            "source_url": "https://example.org/paper", "verification_status": "verified",
        })
        write_csv(root / "corpus.csv", CORPUS_FIELDS, [corpus_row])
        paper_row = {field: "" for field in PAPER_FIELDS}
        paper_row.update({
            "paper_id": "p1", "journal": "Test Journal", "title": "A paper",
            "authors": "A. Author", "year": "2025", "venue": "Test Journal",
            "document_type": "article", "verification_status": "verified",
            "analysis_level": "abstract", "selection_reason": "representative",
            "source_url": "https://example.org/paper",
        })
        write_csv(root / "representative-papers.csv", PAPER_FIELDS, [paper_row])
        write_csv(root / "review-issues.csv", ISSUE_FIELDS, [])
        (root / "search-log.json").write_text(json.dumps({
            "search_date": "2025-01-02", "cutoff_date": "2025-01-02", "scope": "2025",
            "queries": ["Test Journal 2025"], "sources_attempted": ["official"],
            "sources_succeeded": ["official"], "sources_failed": [],
            "sources_not_connected": [], "dedup_before": 1, "dedup_after": 1,
            "dedup_rules": ["DOI", "stable_id", "normalized_bibliography"],
        }, ensure_ascii=False), encoding="utf-8")
        (root / "final-report.md").write_text("# Test report\n", encoding="utf-8")
        (root / "context-capsule.json").write_text(json.dumps({
            "capsule_version": 1,
            "updated_at": "2025-01-02T12:00:00+00:00",
            "mode": "full",
            "checkpoint": "final",
            "task_scope": {"journal": "Test Journal", "years": [2025]},
            "journal_identity": {"name": "Test Journal", "claim_ids": ["c1"]},
            "confirmed_claim_ids": ["c1"],
            "representative_paper_ids": ["p1"],
            "open_questions": [],
            "source_conflicts": [],
            "completed_steps": ["identity", "search", "review"],
            "next_actions": [],
            "hard_constraints": ["Do not infer acceptance from publication count"],
            "artifact_index": {
                "evidence_ledger": "evidence-ledger.csv",
                "corpus": "corpus.csv",
                "search_log": "search-log.json",
                "representative_papers": "representative-papers.csv",
                "review_issues": "review-issues.csv",
                "context_capsule": "context-capsule.json",
                "final_report": "final-report.md",
            },
            "review_state": {
                "current_round": 2, "blockers_open": 0, "major_open": 0,
                "independent_review": False,
            },
        }, ensure_ascii=False), encoding="utf-8")
        valid = validate_run(root, "full")
        if valid.errors:
            raise AssertionError(f"valid fixture failed: {valid.errors}")

        ledger_row.update({"source_url": "", "source_level": "4"})
        write_csv(root / "evidence-ledger.csv", LEDGER_FIELDS, [ledger_row])
        paper_row.update({"analysis_level": "fulltext", "fulltext_source_url": ""})
        write_csv(root / "representative-papers.csv", PAPER_FIELDS, [paper_row])
        issue_row = {field: "" for field in ISSUE_FIELDS}
        issue_row.update({
            "issue_id": "i1", "reviewer": "self", "round": "1", "location": "summary",
            "dimension": "evidence", "severity": "blocker", "description": "unsupported",
            "action": "review", "status": "manual_review",
        })
        write_csv(root / "review-issues.csv", ISSUE_FIELDS, [issue_row])
        capsule = json.loads((root / "context-capsule.json").read_text(encoding="utf-8"))
        capsule["confirmed_claim_ids"] = ["missing-claim"]
        capsule["artifact_index"]["final_report"] = "../outside.md"
        (root / "context-capsule.json").write_text(
            json.dumps(capsule, ensure_ascii=False), encoding="utf-8"
        )
        invalid = validate_run(root, "full")
        expected_fragments = (
            "requires source_url", "source_level=4", "fulltext_source_url", "blocker must",
            "unknown claim_id", "escapes audit directory",
        )
        joined = "\n".join(invalid.errors)
        missing = [fragment for fragment in expected_fragments if fragment not in joined]
        if missing:
            raise AssertionError(f"invalid fixture missed checks: {missing}; errors={invalid.errors}")
    print("self-test passed")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("directory", nargs="?", type=Path, help="audit package directory")
    parser.add_argument("--mode", choices=("quick", "full", "compare"), default="full")
    parser.add_argument("--self-test", action="store_true")
    args = parser.parse_args()
    if args.self_test:
        self_test()
        return 0
    if args.directory is None:
        parser.error("directory is required unless --self-test is used")
    audit = validate_run(args.directory, args.mode)
    for message in audit.errors:
        print(f"ERROR: {message}")
    for message in audit.warnings:
        print(f"WARNING: {message}")
    print(f"summary: {len(audit.errors)} error(s), {len(audit.warnings)} warning(s)")
    return 1 if audit.errors else 0


if __name__ == "__main__":
    sys.exit(main())
