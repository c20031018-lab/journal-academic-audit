#!/usr/bin/env python3
"""Scan a skill package or audit output for privacy and capability risks."""

from __future__ import annotations

import argparse
import re
import sys
import tempfile
import zipfile
from pathlib import Path, PurePosixPath
from urllib.parse import parse_qsl, urlsplit


TEXT_SUFFIXES = {
    ".csv", ".json", ".md", ".py", ".sh", ".txt", ".yaml", ".yml",
}
CODE_SUFFIXES = {".py", ".sh", ".js", ".ts"}
IGNORED_PARTS = {".git", "__pycache__", ".DS_Store"}
SENSITIVE_QUERY_PARTS = (
    "access_token", "api_key", "apikey", "auth", "authorization", "code",
    "credential", "key", "password", "secret", "session", "sig", "signature",
    "token", "x-amz-", "utm_",
)

PATTERNS = {
    "private key": re.compile(r"-----BEGIN [A-Z ]*PRIVATE KEY-----"),
    "AWS access key": re.compile(r"\b(?:AKIA|ASIA)[0-9A-Z]{16}\b"),
    "OpenAI-style secret": re.compile(r"\bsk-[A-Za-z0-9_-]{16,}\b"),
    "GitHub token": re.compile(r"\b(?:gh[pousr]_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{20,})\b"),
    "home-directory path": re.compile(
        r"(?:/" + r"Users/[^/\s]+|/" + r"home/[^/\s]+|[A-Za-z]:\\" + r"Users\\[^\\\s]+)"
    ),
    "email address": re.compile(r"(?<![\w.+-])[\w.+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}(?![\w.-])"),
    "Chinese mobile number": re.compile(r"(?<!\d)(?:\+?86[- ]?)?1[3-9]\d{9}(?!\d)"),
}
URL_PATTERN = re.compile(r"https?://[^\s<>\]\[\)\(\"']+")
CODE_RISKS = {
    "process execution": re.compile(r"\b(?:subprocess\.|os\.system\s*\(|popen\s*\()"),
    "environment or credential access": re.compile(r"\b(?:os\.environ|getenv\s*\(|keyring\.|credential)"),
    "network client": re.compile(r"\b(?:requests\.|httpx\.|urllib\.request|socket\.)"),
}


def text_findings(label: str, text: str, profile: str, suffix: str) -> list[str]:
    findings: list[str] = []
    for kind, pattern in PATTERNS.items():
        if pattern.search(text):
            findings.append(f"{label}: contains {kind}")

    for match in URL_PATTERN.finditer(text):
        raw = match.group(0).rstrip(".,;:")
        parsed = urlsplit(raw)
        host = (parsed.hostname or "").casefold()
        if host in {"localhost", "0.0.0.0", "127.0.0.1", "::1"}:
            findings.append(f"{label}: contains local or loopback URL")
        if host.startswith(("10.", "192.168.", "172.16.", "172.17.", "172.18.", "172.19.", "172.2", "172.30.", "172.31.")):
            findings.append(f"{label}: contains private-network URL")
        for key, _ in parse_qsl(parsed.query, keep_blank_values=True):
            normalized = key.casefold()
            if any(part in normalized for part in SENSITIVE_QUERY_PARTS):
                findings.append(f"{label}: URL contains sensitive or tracking query parameter")
                break

    if profile == "package" and suffix in CODE_SUFFIXES:
        for kind, pattern in CODE_RISKS.items():
            if pattern.search(text):
                findings.append(f"{label}: code contains {kind}")
    return findings


def scan_directory(root: Path, profile: str) -> list[str]:
    findings: list[str] = []
    for path in sorted(root.rglob("*")):
        relative = path.relative_to(root)
        if any(part in IGNORED_PARTS for part in relative.parts):
            if path.name == ".DS_Store":
                findings.append(f"{relative}: forbidden metadata file")
            continue
        if not path.is_file() or path.suffix.casefold() not in TEXT_SUFFIXES:
            continue
        try:
            text = path.read_text(encoding="utf-8-sig")
        except (OSError, UnicodeError):
            findings.append(f"{relative}: cannot safely decode text file")
            continue
        relative_name = relative.as_posix()
        scan_profile = "output" if relative_name.endswith("scripts/security_scan.py") else profile
        findings.extend(text_findings(str(relative), text, scan_profile, path.suffix.casefold()))
    return findings


def has_unix_uid_gid_extra(extra: bytes) -> bool:
    index = 0
    while index + 4 <= len(extra):
        header_id = int.from_bytes(extra[index:index + 2], "little")
        size = int.from_bytes(extra[index + 2:index + 4], "little")
        if header_id == 0x7875:
            return True
        index += 4 + size
    return False


def scan_zip(path: Path, profile: str) -> list[str]:
    findings: list[str] = []
    try:
        with zipfile.ZipFile(path) as archive:
            if archive.comment:
                findings.append("archive: contains ZIP comment")
            for info in archive.infolist():
                name = info.filename
                pure = PurePosixPath(name)
                if pure.is_absolute() or ".." in pure.parts:
                    findings.append(f"{name}: unsafe archive path")
                if ".DS_Store" in pure.parts:
                    findings.append(f"{name}: forbidden metadata file")
                if has_unix_uid_gid_extra(info.extra):
                    findings.append(f"{name}: contains Unix UID/GID metadata")
                if info.is_dir() or Path(name).suffix.casefold() not in TEXT_SUFFIXES:
                    continue
                try:
                    text = archive.read(info).decode("utf-8-sig")
                except (KeyError, UnicodeError):
                    findings.append(f"{name}: cannot safely decode text file")
                    continue
                scan_profile = "output" if name.endswith("/scripts/security_scan.py") else profile
                findings.extend(text_findings(name, text, scan_profile, Path(name).suffix.casefold()))
    except (OSError, zipfile.BadZipFile) as exc:
        findings.append(f"archive: cannot read ZIP: {exc}")
    return findings


def scan(target: Path, profile: str) -> list[str]:
    if target.is_dir():
        return scan_directory(target, profile)
    if target.is_file() and target.suffix.casefold() == ".zip":
        return scan_zip(target, profile)
    return ["target: expected a directory or ZIP file"]


def self_test() -> None:
    with tempfile.TemporaryDirectory(prefix="journal-security-") as temp:
        root = Path(temp)
        safe = root / "safe"
        safe.mkdir()
        (safe / "report.md").write_text("Source: https://example.org/article\n", encoding="utf-8")
        if scan(safe, "output"):
            raise AssertionError("safe fixture produced findings")

        unsafe = root / "unsafe"
        unsafe.mkdir()
        unsafe_text = (
            "Contact: private" + chr(64) + "example.org\n"
            + "/" + "Users/example/private\n"
            + "Source: https://example.org/article?" + "sess" + "ion=temporary\n"
        )
        (unsafe / "report.md").write_text(
            unsafe_text,
            encoding="utf-8",
        )
        kinds = "\n".join(scan(unsafe, "output"))
        for expected in ("email address", "home-directory path", "sensitive or tracking"):
            if expected not in kinds:
                raise AssertionError(f"unsafe fixture missed {expected}")
    print("self-test passed")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("target", nargs="?", type=Path)
    parser.add_argument("--profile", choices=("package", "output"), default="output")
    parser.add_argument("--self-test", action="store_true")
    args = parser.parse_args()
    if args.self_test:
        self_test()
        return 0
    if args.target is None:
        parser.error("target is required unless --self-test is used")
    findings = sorted(set(scan(args.target, args.profile)))
    for finding in findings:
        print(f"ERROR: {finding}")
    print(f"summary: {len(findings)} finding(s)")
    return 1 if findings else 0


if __name__ == "__main__":
    sys.exit(main())
