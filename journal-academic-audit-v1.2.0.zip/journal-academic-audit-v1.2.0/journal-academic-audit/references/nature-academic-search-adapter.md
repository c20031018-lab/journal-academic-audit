# nature-academic-search 适配契约

仅在该Skill实际可用并被调用时采用此适配；不可用时记录 `sources_not_connected`，不得声称已查询。

## 输入

向搜索Skill提供：规范刊名及别名、ISSN、年份范围、主题词、文献类型、最大返回量和需要的稳定ID。期刊身份未消歧前，不直接用宽泛刊名构建最终语料。

## 输出映射

| 搜索输出 | 本Skill产物 |
|---|---|
| `sources_queried` | `search-log.sources_attempted` |
| `sources_succeeded` | `search-log.sources_succeeded` |
| `sources_skipped` | `sources_not_connected` 或失败记录 |
| `errors` | `sources_failed[].reason` |
| `raw_result_count` | `dedup_before` 的一个输入，不自动等同总数 |
| `result_count` | `dedup_after` 的一个输入，仍需跨源去重 |
| `verification.status` | 论文或语料的 `verification_status` |
| `lookup_id` + `lookup_id_type` | DOI或 `stable_id` |
| `unchecked_identifiers` | `notes` 与人工核验清单 |

## 纳入规则

- `verified` 结果可自动进入候选语料；仍需检查年份、期刊版本和文献类型。
- `mismatch` 从目标语料排除，并记录排除理由。
- `manual_needed` 可保留为候选，但不得作为已核验代表论文或关键趋势证据。
- 搜索Skill的“找到”不等于本Skill的“已核验”；本Skill仍负责来源层级、时效、对象及内容分析层级。
- 搜索Skill失败不应导致用常识补全；应转为失败、未连接或人工核验状态。
