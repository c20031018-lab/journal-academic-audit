# 跨AI运行兼容说明

## 1. 可移植核心

`SKILL.md`、`references/`、`scripts/` 和 `LICENSE.txt` 是唯一规范源。`agents/openai.yaml` 是OpenAI/Codex界面元数据，其他Agent可以忽略。不要为不同平台维护内容不同的 `SKILL.md`。

项目级安装优先使用复制而不是压缩包内符号链接，避免Windows、Git和云端解压环境破坏链接。

## 2. 常见安装位置

| 环境 | 项目级或个人级位置 | 调用方式 |
|---|---|---|
| Codex | `~/.codex/skills/journal-academic-audit/` | `$journal-academic-audit` 或自然语言触发 |
| Claude Code | `.claude/skills/journal-academic-audit/` 或 `~/.claude/skills/` | 自动选择或 `/journal-academic-audit` |
| Cursor | `.agents/skills/`、`.cursor/skills/` 或其个人目录 | `/journal-academic-audit` 或 `@journal-academic-audit` |
| GitHub Copilot | `.github/skills/`、`.agents/skills/` 或 `.claude/skills/` | `/journal-academic-audit` 或自动选择 |
| Gemini CLI | `.agents/skills/journal-academic-audit/` | 用 `/skills` 确认后自然语言调用 |
| Windsurf | `.agents/skills/`、`.windsurf/skills/` 或个人目录 | `@journal-academic-audit` 或自动选择 |
| TRAE | 使用产品内Agent Skills导入功能 | 在Skills界面选择或按产品支持方式触发 |

`.agents/skills/` 是多个Agent共同识别的项目目录，但Codex和Claude Code仍应保留各自明确的安装说明。

## 3. 能力降级

- **无网络**：进入 `offline`，只处理用户提供的材料；当前投稿制度、指标和时效事实全部标为未连接或待人工核验。
- **无Python 3.9+**：允许完成人工分析，但必须声明确定性校验与隐私扫描未运行。
- **无文件系统或脚本执行**：将整个目录作为附件，要求先读取 `SKILL.md`；只能视为提示词兼容，不能声称完整Skill运行。
- **无浏览器但有用户提供的网页/PDF**：仅按实际可见内容选择全文级、摘要级或题录级分析，不推断缺失信息。

## 4. 发布包要求

- 顶层目录包含版本号，内部保留名为 `journal-academic-audit` 的完整Skill目录。
- 不包含 `.DS_Store`、缓存、运行产物、用户附件、绝对路径、凭证或Git历史。
- ZIP不写入文件注释、UID/GID扩展字段或平台专属扩展属性。
- 发布前运行 `audit_run.py --self-test`、`security_scan.py --self-test` 和包级安全扫描。
