# 审计包产物契约

所有CSV使用UTF-8、首行为固定字段名；空值保留为空字符串，不用“无”“未知”代替。每次运行放在独立目录。枚举值在机器文件中使用下列英文值，报告正文可显示中文。

## 通用枚举

- `evidence_status`: `verified`, `partially_verified`, `not_public`, `not_found`, `source_conflict`, `manual_review`, `not_applicable`
- `confidence`: `high`, `medium`, `low`, `not_assessed`
- `analysis_level`: `fulltext`, `abstract`, `bibliographic`, `not_applicable`
- 布尔值：`true` 或 `false`

## evidence-ledger.csv

字段：

```text
claim_id,journal,issn,section,field,claim,critical,source_url,source_title,source_level,source_date,access_date,valid_for_year,scope,evidence_status,confidence,analysis_level,notes
```

- `claim_id` 唯一；`critical` 使用 `true/false`。
- `verified` 必须有来源URL、标题、等级和访问日期。
- 关键断言不能仅依赖 `source_level=4`。
- `source_date` 是来源发布/更新日，`access_date` 是访问日，`valid_for_year` 是结论适用年度，三者不可混用。
- 一个断言有多个来源时可使用多行，但每行仍须唯一ID，并在 `notes` 关联同一断言组。
- 所有URL删除片段、认证、会话、签名和跟踪参数；禁止 `file://`、本机地址、私有网络地址和本机绝对路径。

## corpus.csv

字段：

```text
record_id,journal,issn,year,issue,title,authors,pages,doi,stable_id,document_type,abstract_available,fulltext_available,source_url,verification_status
```

- `record_id` 唯一；`journal`、`year`、`title` 必填。
- `abstract_available`、`fulltext_available` 使用布尔值。
- 保留去重后的逐条记录；不要只保存年度数量。
- 疑似重复可保留，但必须在日志说明未自动合并的原因。

## search-log.json

最低结构：

```json
{
  "search_date": "YYYY-MM-DD",
  "cutoff_date": "YYYY-MM-DD",
  "scope": "...",
  "queries": ["..."],
  "sources_attempted": ["..."],
  "sources_succeeded": ["..."],
  "sources_failed": [{"source": "...", "reason": "..."}],
  "sources_not_connected": ["..."],
  "dedup_before": 0,
  "dedup_after": 0,
  "dedup_rules": ["DOI", "stable_id", "normalized_bibliography"]
}
```

成功和失败来源必须属于尝试来源；`dedup_after` 不得大于 `dedup_before`。`quick` 模式未建语料时两个去重数可为0，并在 `scope` 说明。

## representative-papers.csv

字段：

```text
paper_id,journal,title,authors,year,venue,volume,issue,pages,doi,stable_id,document_type,verification_status,analysis_level,selection_reason,source_url,fulltext_source_url
```

- `paper_id` 唯一；标为 `verified` 必须有来源URL。
- `analysis_level=fulltext` 必须提供实际全文来源，不得仅给摘要页。

## review-issues.csv

字段：

```text
issue_id,reviewer,round,location,dimension,severity,description,action,status,notes
```

- `reviewer`: `self` 或明确的独立审查者/流程标识。
- `severity`: `blocker`, `major`, `general`, `minor`。
- `status`: `fixed`, `downgraded`, `deleted`, `manual_review`, `accepted_risk`。
- 阻断级问题不得以 `manual_review` 或 `accepted_risk` 交付；重大问题不得用 `accepted_risk` 回避。
- 没有发现问题时保留表头，并在报告中写明审查范围，不能虚构问题。

## final-report.md

按报告Schema生成，且非空。机器校验不解析自然语言事实是否真实，内容审查仍是必需步骤。

## context-capsule.json

上下文胶囊是执行状态索引，不是事实或引文的替代品。最低结构：

```json
{
  "capsule_version": 1,
  "updated_at": "YYYY-MM-DDTHH:MM:SS+08:00",
  "mode": "quick",
  "checkpoint": "final",
  "task_scope": {},
  "journal_identity": {"claim_ids": ["c01"]},
  "confirmed_claim_ids": ["c01"],
  "representative_paper_ids": ["p01"],
  "open_questions": [
    {"question": "...", "status": "manual_review", "related_claim_ids": ["c02"]}
  ],
  "source_conflicts": [],
  "completed_steps": ["identity", "search"],
  "next_actions": [],
  "hard_constraints": ["不得用发表量反推接收率"],
  "artifact_index": {
    "evidence_ledger": "evidence-ledger.csv",
    "search_log": "search-log.json",
    "representative_papers": "representative-papers.csv",
    "review_issues": "review-issues.csv",
    "final_report": "final-report.md"
  },
  "review_state": {
    "current_round": 2,
    "blockers_open": 0,
    "major_open": 0,
    "independent_review": false
  }
}
```

- `capsule_version` 为正整数，每次重写递增；`updated_at` 必须带时区。
- `mode`: `quick`, `full`, `compare`；必须与实际运行模式一致。
- `checkpoint`: `identity`, `search`, `papers`, `predraft`, `review_round_1`, `review_round_2`, `final`。
- `confirmed_claim_ids`、身份及开放问题中的 `claim_id` 必须存在于证据台账；`representative_paper_ids` 必须存在于代表论文表。
- `open_questions[].status`: `open`, `manual_review`, `resolved`。未解决问题不得在恢复时静默丢弃。
- `source_conflicts` 至少保存冲突摘要、相关 `claim_id` 和处理状态；不能压缩成单一结论。
- `artifact_index` 使用相对路径；列出的产物必须存在且不能逃逸审计包目录。
- `review_state` 必须反映最终审查状态；`final` 检查点不得有未解决阻断级或重大问题。
- 胶囊不保存长篇来源正文、全文或新的无来源事实。事实必须通过ID回到台账。
- `task_scope`、开放问题和下一步不得复制原始用户提示、姓名、联系方式、账号、凭证或设备路径；只保存完成任务所需的非识别性范围信息。

### 自动更新节点

依次在身份消歧后、检索后、代表论文筛选后、初稿前、每轮审查后及最终交付时更新。任务中断、切换执行者或跨会话前立即更新。若一个短任务一次完成多个节点，可只写最新快照；最终快照不可省略。

### 恢复协议

先读取本Skill和胶囊，再按 `artifact_index` 打开证据台账、检索日志和当前报告；核验所有引用ID后执行 `next_actions`。胶囊与原始产物冲突时，以原始产物为准并修正胶囊。

## 模式所需文件

- `quick`: 除 `corpus.csv` 外的六项必需；若报告作出年度趋势、词频或共现结论，`corpus.csv` 也必需。
- `full`: 七项全部必需。
- `compare`: 七项全部必需，所有CSV中的 `journal` 字段用于区分对象。
